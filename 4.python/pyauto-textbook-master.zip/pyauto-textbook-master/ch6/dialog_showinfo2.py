import tkinter as tk
import tkinter.messagebox as mb

# tkinter 창 숨기기 --- (1)
tk.Tk().withdraw()

# 메시지 표시 --- (2)
mb.showinfo("격언", "두 번 일어난 일은 세 번도 일어난다")

