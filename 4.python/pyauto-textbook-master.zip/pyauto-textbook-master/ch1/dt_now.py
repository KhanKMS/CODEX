# 날짜·시간 관련 처리를 하는 모듈 --- (1)
import datetime

# 현재 시각 구하기 --- (2)
t = datetime.datetime.now()
print(t) # 현재 시각을 문자열로 출력

