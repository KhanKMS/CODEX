# 3부터 5까지 반복 --- (*A)
for i in range(3,6):
    print(i)
# 결과→ 3 \n 4 \n 5

# 0부터 5까지 2간격으로 반복 --- (*B)
for i in range(0, 6, 2):
    print(i)
# 결과→ 0 \n 2 \n 4

