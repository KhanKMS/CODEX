i = 0
while i <= 3:
    print(i)
    i+=1
# 결과: 0 \n 1 \n 2 \n 3

