import os
URL = 'http://127.0.0.1:5000/'
DRIVER = os.path.join(os.path.dirname(__file__), 'input','chromedriver')