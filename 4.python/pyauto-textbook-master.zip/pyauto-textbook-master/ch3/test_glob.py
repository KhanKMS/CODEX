import glob
# 파일 목록 받아오기
files = glob.glob("*.py")
# 파일 목록 출력하기
print(files)
