#!/bin/sh
# --- 3개의 파이썬 프로그램을 연속으로 실행 ---
python3 step1_merge_files.py
python3 step2_split_data.py
python3 step3_fill_template.py

