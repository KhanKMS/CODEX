fruits = ["사과", "바나나", "포도"]
for i, v in enumerate(fruits):
    print(i, "=", v)

